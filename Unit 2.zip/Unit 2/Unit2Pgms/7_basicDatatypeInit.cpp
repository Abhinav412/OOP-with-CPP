#include<iostream>
using namespace std;

int main()
{
	int a=2;
	int b(3);
	int c{4};
	
	cout<<a<<" "<<b<<" "<<c<<endl;
}