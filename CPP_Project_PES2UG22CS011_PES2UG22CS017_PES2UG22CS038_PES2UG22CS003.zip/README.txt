# Phone Book Application Readme

This is a simple phone book application written in C++. The application allows users to manage contacts, 
including inserting, sorting, updating, deleting, and searching for contacts by name, phone number, or email.

## How to Run the Code

### Prerequisites

Before running the code, ensure that you have a C++ compiler installed on your system. 
If you don't have one, you can install a compiler like g++ on Linux or MinGW on Windows.

### Steps to Run

1. **Compile the Code:**

   On Linux:

   ```bash```
   g++ -o phonebook main.cpp
   

   On Windows (using MinGW):

   ```bash```

   g++ -o phonebook.exe main.cpp
   

2. **Run the Executable:**

   On Linux:

   ```bash```

   ./phonebook
   

   On Windows:

   ```bash```

   phonebook.exe
   

3. **Follow On-screen Instructions:**

   The program will prompt you to enter your name and then guide you through various options to interact with the phone book application. 
   Follow the on-screen instructions to perform operations like displaying contacts, inserting new ones, 
   updating existing ones, deleting contacts, and searching for contacts.

## Notes

- The program uses a simple console interface.
- Ensure that you provide valid input when prompted, especially for phone numbers.
- The code includes basic error handling for invalid input lengths.

